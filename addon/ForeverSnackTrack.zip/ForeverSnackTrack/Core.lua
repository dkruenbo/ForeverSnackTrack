local addonName, ns = ...

local defaults = {
	chatAlerts = true,
	screenAlerts = true,
	remindWhenNoFood = false,
	remindWhileResting = false,
	repeatReminders = true,
	reminderMinutes = 1,
	snoozeMinutes = 1,
	screenMessage = "",
	screenDuration = 0,
	screenScale = 1,
	alertOffsetX = 0,
	alertOffsetY = 120,
}

local foodTooltipCache = {}
local auraTooltipCache = {}
local cachedBagResult
local tooltipCacheTime
local lastReminderTime
local reminderState
local dismissedReminderState
local snoozeUntil
local scanTicker

local snoozeDurations = { 1, 5, 10, 15, 30, 60 }
local uppercaseToLowercase = {
	["Ä"] = "ä", ["Ö"] = "ö", ["Ü"] = "ü", ["Á"] = "á", ["É"] = "é",
	["Í"] = "í", ["Ó"] = "ó", ["Ú"] = "ú", ["À"] = "à", ["È"] = "è",
	["Ì"] = "ì", ["Ò"] = "ò", ["Ù"] = "ù", ["Ê"] = "ê", ["Â"] = "â",
	["Î"] = "î", ["Ô"] = "ô", ["Û"] = "û", ["Ç"] = "ç", ["Ñ"] = "ñ",
	["Ё"] = "ё", ["А"] = "а", ["Б"] = "б", ["В"] = "в", ["Г"] = "г",
	["Д"] = "д", ["Е"] = "е", ["Ж"] = "ж", ["З"] = "з", ["И"] = "и",
	["Й"] = "й", ["К"] = "к", ["Л"] = "л", ["М"] = "м", ["Н"] = "н",
	["О"] = "о", ["П"] = "п", ["Р"] = "р", ["С"] = "с", ["Т"] = "т",
	["У"] = "у", ["Ф"] = "ф", ["Х"] = "х", ["Ц"] = "ц", ["Ч"] = "ч",
	["Ш"] = "ш", ["Щ"] = "щ", ["Ъ"] = "ъ", ["Ы"] = "ы", ["Ь"] = "ь",
	["Э"] = "э", ["Ю"] = "ю", ["Я"] = "я",
}

local function normalizeTooltipText(text)
	text = text:lower()
	for uppercase, lowercase in pairs(uppercaseToLowercase) do
		text = text:gsub(uppercase, lowercase)
	end
	return text
end

local function containsAny(text, terms)
	for _, term in ipairs(terms) do
		if text:find(term, 1, true) then
			return true
		end
	end
	return false
end

local function hasExperienceKillContext(text)
	return containsAny(text, ForeverSnackTrackL.experienceTerms)
		and containsAny(text, ForeverSnackTrackL.killTerms)
		and containsAny(text, ForeverSnackTrackL.increaseTerms)
end

local function distanceToTerms(text, terms, percentStart, percentEnd)
	local closestDistance = math.huge
	for _, term in ipairs(terms) do
		local searchStart = 1
		while true do
			local termStart, termEnd = text:find(term, searchStart, true)
			if not termStart then
				break
			end

			local distance
			if termEnd < percentStart then
				distance = percentStart - termEnd
			elseif termStart > percentEnd then
				distance = termStart - percentEnd
			else
				distance = 0
			end
			closestDistance = math.min(closestDistance, distance)
			searchStart = termStart + 1
		end
	end
	return closestDistance
end

local function tooltipLineText(line)
	return table.concat({ line.leftText or "", line.rightText or "" }, " ")
end

local function debugPrint(message)
	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cff80d7ffForever SnackTrack debug:|r " .. message)
	end
end

local function initializeSettings()
	if type(ForeverSnackTrackDB) ~= "table" then
		ForeverSnackTrackDB = type(ForeverExpFoodDB) == "table" and ForeverExpFoodDB or {}
	end

	for key, value in pairs(defaults) do
		if type(ForeverSnackTrackDB[key]) ~= type(value) then
			ForeverSnackTrackDB[key] = value
		end
	end

	ForeverSnackTrackDB.reminderMinutes = math.max(1, math.min(60, math.floor(ForeverSnackTrackDB.reminderMinutes)))
	local validSnoozeDuration = false
	for _, minutes in ipairs(snoozeDurations) do
		if ForeverSnackTrackDB.snoozeMinutes == minutes then
			validSnoozeDuration = true
			break
		end
	end
	if not validSnoozeDuration then
		ForeverSnackTrackDB.snoozeMinutes = defaults.snoozeMinutes
	end
	if ForeverSnackTrackDB.screenDuration ~= 0 then
		ForeverSnackTrackDB.screenDuration = math.max(1, math.min(20, math.floor(ForeverSnackTrackDB.screenDuration)))
	end
	ForeverSnackTrackDB.screenScale = math.max(0.75, math.min(1.5, ForeverSnackTrackDB.screenScale))
	if type(ForeverSnackTrackDB.screenColor) ~= "table" then
		ForeverSnackTrackDB.screenColor = { r = 1, g = 0.82, b = 0 }
	else
		for _, channel in ipairs({ "r", "g", "b" }) do
			local value = ForeverSnackTrackDB.screenColor[channel]
			if type(value) ~= "number" or value ~= value then
				ForeverSnackTrackDB.screenColor[channel] = channel == "r" and 1 or channel == "g" and 0.82 or 0
			else
				ForeverSnackTrackDB.screenColor[channel] = math.max(0, math.min(1, value))
			end
		end
	end
	ns.db = ForeverSnackTrackDB
end

local function tooltipExperienceBonusPercent(tooltipData)
	if not tooltipData or type(tooltipData.lines) ~= "table" or #tooltipData.lines == 0 then
		return nil
	end
	for _, line in ipairs(tooltipData.lines) do
		local text = tooltipLineText(line)
		if RETRIEVING_ITEM_INFO and text:find(RETRIEVING_ITEM_INFO, 1, true) then
			return nil
		end
	end

	for _, line in ipairs(tooltipData.lines) do
		local text = normalizeTooltipText(tooltipLineText(line))
		if hasExperienceKillContext(text) then
			local searchStart = 1
			local closestPercent
			local closestDistance = math.huge
			while true do
				local matchStart, matchEnd, percentage = text:find("(%d+)%s*%%", searchStart)
				if not matchStart then
					break
				end

				local previousCharacter = matchStart > 1 and text:sub(matchStart - 1, matchStart - 1)
				if not previousCharacter or not previousCharacter:match("[%d%.,]") then
					local value = tonumber(percentage)
					if value and value > 0 then
						local experienceDistance = distanceToTerms(
							text, ForeverSnackTrackL.experienceTerms, matchStart, matchEnd
						)
						local increaseDistance = distanceToTerms(
							text, ForeverSnackTrackL.increaseTerms, matchStart, matchEnd
						)
						local distance = experienceDistance + increaseDistance * 2
						if distance < closestDistance then
							closestPercent = value
							closestDistance = distance
						end
					end
				end
				searchStart = matchEnd + 1
			end
			if closestPercent then
				return closestPercent
			end
		end
	end
	return false
end

local function foodItemType(itemID)
	local getInfo = C_Item and C_Item.GetItemInfoInstant or GetItemInfoInstant
	if not getInfo then
		return nil
	end
	local _, _, _, _, _, classID, subclassID = getInfo(itemID)
	if classID == nil or subclassID == nil then
		return nil
	end
	return classID == 0 and subclassID == 5
end

local function hasQualifyingFood()
	if cachedBagResult ~= nil then
		return cachedBagResult
	end
	if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then
		return nil
	end

	local unresolvedTooltip = false
	local bestBonusPercent = 0
	local bagCount = NUM_BAG_SLOTS or 0
	for bagID = 0, bagCount do
		local slotCount = C_Container.GetContainerNumSlots(bagID) or 0
		for slot = 1, slotCount do
			local itemInfo = C_Container.GetContainerItemInfo(bagID, slot)
			local itemID = itemInfo and itemInfo.itemID
			if itemID then
				local isFood = foodItemType(itemID)
				local bonusPercent = foodTooltipCache[itemID]
				if isFood == nil then
					unresolvedTooltip = true
					bonusPercent = nil
				elseif not isFood then
					bonusPercent = false
				elseif bonusPercent == nil then
					local tooltipData = C_TooltipInfo and C_TooltipInfo.GetBagItem
						and C_TooltipInfo.GetBagItem(bagID, slot)
					if tooltipData and type(tooltipData.lines) == "table" and #tooltipData.lines > 1 then
						bonusPercent = tooltipExperienceBonusPercent(tooltipData)
						if type(bonusPercent) == "number" then
							foodTooltipCache[itemID] = bonusPercent
						elseif bonusPercent == nil then
							unresolvedTooltip = true
						end
					else
						unresolvedTooltip = true
					end
				end
				if type(bonusPercent) == "number" and bonusPercent > bestBonusPercent then
					bestBonusPercent = bonusPercent
				end
			end
		end
	end

	if unresolvedTooltip then
		return bestBonusPercent > 0 and bestBonusPercent or nil
	end
	cachedBagResult = bestBonusPercent > 0 and bestBonusPercent or false
	return cachedBagResult
end

local function invalidateBagScan(itemID)
	cachedBagResult = nil
	if itemID then
		foodTooltipCache[itemID] = nil
	end
end

local function hasExperienceBuff()
	if not C_UnitAuras or not C_UnitAuras.GetAuraDataByIndex
		or not C_TooltipInfo or not C_TooltipInfo.GetUnitBuff then
		return nil
	end

	local index = 1
	local unresolvedTooltip = false
	local bestBonusPercent = 0
	while true do
		local aura = C_UnitAuras.GetAuraDataByIndex("player", index, "HELPFUL")
		if not aura then
			if unresolvedTooltip then
				return nil
			end
			return bestBonusPercent > 0 and bestBonusPercent or false
		end

		local bonusPercent = aura.spellId and auraTooltipCache[aura.spellId]
		if bonusPercent == nil then
			local tooltipData = C_TooltipInfo.GetUnitBuff("player", index, "HELPFUL")
			if tooltipData and type(tooltipData.lines) == "table" and #tooltipData.lines > 0 then
				bonusPercent = tooltipExperienceBonusPercent(tooltipData)
				if #tooltipData.lines == 1 and aura.name and tooltipData.lines[1].leftText == aura.name then
					bonusPercent = nil
				end
				if bonusPercent == nil then
					unresolvedTooltip = true
				elseif aura.spellId and type(bonusPercent) == "number" then
					auraTooltipCache[aura.spellId] = bonusPercent
				end
			else
				unresolvedTooltip = true
			end
		end
		if type(bonusPercent) == "number" and bonusPercent > bestBonusPercent then
			bestBonusPercent = bonusPercent
		end
		index = index + 1
	end
end

local function sendReminder(message, useCustomScreenMessage)
	local sent = false
	if ns.db.chatAlerts and DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage("|cff80d7ffForever SnackTrack:|r " .. message)
		sent = true
	end
	if ns.db.screenAlerts and ns.ShowScreenAlert
		and not (ns.alertFrame and ns.alertFrame.isPreview and ns.alertFrame:IsShown()) then
		local screenMessage = useCustomScreenMessage and ns.db.screenMessage ~= "" and ns.db.screenMessage or message
		sent = ns.ShowScreenAlert(screenMessage) or sent
	end
	return sent
end

function ns.Scan()
	if not ns.db then
		return
	end
	if not ns.db.remindWhileResting and IsResting and IsResting() then
		if ns.HideScreenAlert then
			ns.HideScreenAlert()
		end
		return
	end
	if UnitAffectingCombat and UnitAffectingCombat("player") then
		if ns.HideScreenAlert then
			ns.HideScreenAlert()
		end
		return
	end
	if not ns.db.chatAlerts and not ns.db.screenAlerts then
		lastReminderTime = nil
		reminderState = nil
		dismissedReminderState = nil
		if ns.HideScreenAlert then
			ns.HideScreenAlert(true)
		end
		return
	end

	local now = GetTime()
	if not tooltipCacheTime or now - tooltipCacheTime >= 60 then
		foodTooltipCache = {}
		auraTooltipCache = {}
		cachedBagResult = nil
		tooltipCacheTime = now
	end

	local hasFood = hasQualifyingFood()
	if hasFood == nil then
		return
	end

	local state
	local message
	local useCustomScreenMessage = false
	if hasFood then
		local hasBuff = hasExperienceBuff()
		if hasBuff == nil then
			return
		elseif type(hasBuff) == "number" and hasBuff >= hasFood then
			lastReminderTime = nil
			reminderState = nil
			dismissedReminderState = nil
			if ns.HideScreenAlert then
				ns.HideScreenAlert(true)
			end
			return
		end
		state = "missing-buff:" .. hasFood
		message = string.format(ForeverSnackTrackL.chatMessage, hasFood)
		useCustomScreenMessage = true
	elseif ns.db.remindWhenNoFood then
		local hasBuff = hasExperienceBuff()
		if hasBuff == nil then
			return
		elseif type(hasBuff) == "number" and hasBuff > 0 then
			lastReminderTime = nil
			reminderState = nil
			dismissedReminderState = nil
			if ns.HideScreenAlert then
				ns.HideScreenAlert(true)
			end
			return
		end
		state = "missing-food"
		message = ForeverSnackTrackL.noFoodMessage
	else
		lastReminderTime = nil
		reminderState = nil
		dismissedReminderState = nil
		if ns.HideScreenAlert then
			ns.HideScreenAlert(true)
		end
		return
	end

	if reminderState ~= state then
		reminderState = state
		lastReminderTime = nil
	end
	if dismissedReminderState and dismissedReminderState ~= state then
		dismissedReminderState = nil
	end
	if dismissedReminderState == state then
		return
	end

	if snoozeUntil then
		if now < snoozeUntil then
			return
		end
		snoozeUntil = nil
	end
	local intervalElapsed = lastReminderTime
		and now - lastReminderTime >= ns.db.reminderMinutes * 60
	if not lastReminderTime or (ns.db.repeatReminders and intervalElapsed) then
		if sendReminder(message, useCustomScreenMessage) then
			lastReminderTime = now
		end
	end
	local frame = ns.alertFrame
	local remaining = lastReminderTime and ns.db.screenDuration > 0
		and lastReminderTime + ns.db.screenDuration - now
	if ns.db.screenAlerts and lastReminderTime and ns.ShowScreenAlert
		and (ns.db.screenDuration == 0 or remaining > 0)
		and not (frame and frame:IsShown()) then
		local screenMessage = useCustomScreenMessage and ns.db.screenMessage ~= "" and ns.db.screenMessage or message
		ns.ShowScreenAlert(screenMessage)
		if remaining and ns.alertFrame then
			ns.alertFrame.remaining = remaining
		end
	end
end

local function debugTooltipCandidates(tooltipData)
	local candidates = {}
	for _, line in ipairs(tooltipData and tooltipData.lines or {}) do
		local rawText = tooltipLineText(line)
		local text = normalizeTooltipText(rawText)
		if rawText:find("%", 1, true)
			or containsAny(text, ForeverSnackTrackL.experienceTerms)
			or containsAny(text, ForeverSnackTrackL.killTerms) then
			table.insert(candidates, rawText)
		end
	end
	return candidates
end

function ns.DebugStatus()
	if not DEFAULT_CHAT_FRAME then
		return
	end
	if not ns.db then
		debugPrint("Settings have not been initialized.")
		return
	end
	debugPrint(string.format("Chat alerts: %s; screen alerts: %s.",
		tostring(ns.db.chatAlerts), tostring(ns.db.screenAlerts)))
	if not ns.db.chatAlerts and not ns.db.screenAlerts then
		debugPrint("Reminders blocked: both alert channels are disabled.")
	end
	local now = GetTime()
	if snoozeUntil and now < snoozeUntil then
		debugPrint(string.format("Reminders snoozed for %d more second(s).", math.ceil(snoozeUntil - now)))
	end
	if dismissedReminderState then
		debugPrint("Dismissed reminder condition: " .. dismissedReminderState)
	end
	if lastReminderTime then
		if ns.db.repeatReminders then
			debugPrint(string.format("Next repeat eligible in %d second(s).",
				math.max(0, math.ceil(ns.db.reminderMinutes * 60 - (now - lastReminderTime)))))
		else
			debugPrint("A reminder was already sent; repeat reminders are disabled.")
		end
	end
	if UnitAffectingCombat and UnitAffectingCombat("player") then
		debugPrint("Leave combat before running the diagnostic.")
		return
	end
	if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo
		or not C_TooltipInfo or not C_TooltipInfo.GetBagItem then
		debugPrint("Bag or tooltip API is unavailable.")
		return
	end

	invalidateBagScan()
	local scannedItems = 0
	local unresolvedItems = 0
	local recognizedFoods = 0
	local bestFoodPercent = 0
	local bagCount = NUM_BAG_SLOTS or 0
	debugPrint("Scanning carried bags and helpful buffs...")
	for bagID = 0, bagCount do
		local slotCount = C_Container.GetContainerNumSlots(bagID) or 0
		for slot = 1, slotCount do
			local itemInfo = C_Container.GetContainerItemInfo(bagID, slot)
			local itemID = itemInfo and itemInfo.itemID
			if itemID and foodItemType(itemID) ~= false then
				scannedItems = scannedItems + 1
				local tooltipData = C_TooltipInfo.GetBagItem(bagID, slot)
				if foodItemType(itemID) == nil or not tooltipData
					or type(tooltipData.lines) ~= "table" or #tooltipData.lines <= 1 then
					unresolvedItems = unresolvedItems + 1
					debugPrint("Item " .. itemID .. ": tooltip data unavailable.")
				else
					local bonusPercent = tooltipExperienceBonusPercent(tooltipData)
					if bonusPercent == nil then
						unresolvedItems = unresolvedItems + 1
					end
					foodTooltipCache[itemID] = type(bonusPercent) == "number" and bonusPercent or nil
					local itemName = itemInfo.itemName or (GetItemInfo and GetItemInfo(itemID)) or ("item " .. itemID)
					if type(bonusPercent) == "number" then
						recognizedFoods = recognizedFoods + 1
						bestFoodPercent = math.max(bestFoodPercent, bonusPercent)
						debugPrint(string.format("Food: %s (ID %d) -> %d%% kill XP", itemName, itemID, bonusPercent))
					else
						for _, candidate in ipairs(debugTooltipCandidates(tooltipData)) do
							debugPrint(string.format("Item candidate %s (ID %d): %s", itemName, itemID, candidate))
						end
					end
				end
			end
		end
	end

	if unresolvedItems == 0 then
		cachedBagResult = bestFoodPercent > 0 and bestFoodPercent or false
	else
		cachedBagResult = nil
	end
	if unresolvedItems > 0 then
		debugPrint(string.format("%d item tooltip(s) unavailable; known XP food can still trigger reminders.", unresolvedItems))
	end
	if recognizedFoods == 0 then
		debugPrint(string.format("No XP food recognized in %d carried item(s).", scannedItems))
	else
		debugPrint(string.format("Recognized %d XP food item(s); best available bonus is %d%%.", recognizedFoods, bestFoodPercent))
	end

	if not C_UnitAuras or not C_UnitAuras.GetAuraDataByIndex or not C_TooltipInfo.GetUnitBuff then
		debugPrint("Aura or unit-tooltip API is unavailable.")
		return
	end

	local auraIndex = 1
	local auraCount = 0
	local recognizedBuffs = 0
	local bestBuffPercent = 0
	while true do
		local aura = C_UnitAuras.GetAuraDataByIndex("player", auraIndex, "HELPFUL")
		if not aura then
			break
		end
		auraCount = auraCount + 1
		local tooltipData = C_TooltipInfo.GetUnitBuff("player", auraIndex, "HELPFUL")
		if not tooltipData or type(tooltipData.lines) ~= "table" or #tooltipData.lines == 0 then
			debugPrint("Buff " .. (aura.name or tostring(aura.spellId)) .. ": tooltip data unavailable.")
		else
			local bonusPercent = tooltipExperienceBonusPercent(tooltipData)
			if #tooltipData.lines == 1 and tooltipData.lines[1].leftText == aura.name then
				bonusPercent = nil
			end
			if aura.spellId then
				auraTooltipCache[aura.spellId] = type(bonusPercent) == "number" and bonusPercent or nil
			end
			if type(bonusPercent) == "number" then
				recognizedBuffs = recognizedBuffs + 1
				bestBuffPercent = math.max(bestBuffPercent, bonusPercent)
				debugPrint(string.format("Buff: %s (spell %s) -> %d%% kill XP", aura.name or "unknown", aura.spellId or "unknown", bonusPercent))
			else
				for _, candidate in ipairs(debugTooltipCandidates(tooltipData)) do
					debugPrint(string.format("Buff candidate %s (spell %s): %s", aura.name or "unknown", aura.spellId or "unknown", candidate))
				end
			end
		end
		auraIndex = auraIndex + 1
	end
	if recognizedBuffs == 0 then
		debugPrint(string.format("No XP kill-buff recognized among %d helpful buff(s).", auraCount))
	else
		debugPrint(string.format("Recognized %d XP buff(s); strongest active bonus is %d%%.", recognizedBuffs, bestBuffPercent))
	end
end

function ns.SnoozeReminders()
	if not ns.db then
		return
	end

	snoozeUntil = GetTime() + ns.db.snoozeMinutes * 60
	lastReminderTime = nil
	if ns.alertFrame then
		ns.HideScreenAlert()
	end
end

function ns.DismissReminder()
	if reminderState then
		dismissedReminderState = reminderState
	end
	lastReminderTime = nil
	if ns.alertFrame then
		ns.HideScreenAlert()
	end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_UPDATE_RESTING")
eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
eventFrame:RegisterEvent("GET_ITEM_INFO_RECEIVED")
if eventFrame.RegisterUnitEvent then
	eventFrame:RegisterUnitEvent("UNIT_AURA", "player")
else
	eventFrame:RegisterEvent("UNIT_AURA")
end

eventFrame:SetScript("OnEvent", function(_, event, arg1)
	if event == "ADDON_LOADED" then
		if arg1 ~= addonName then
			return
		end
		eventFrame:UnregisterEvent("ADDON_LOADED")
		initializeSettings()
		if ns.InitializeOptions then
			ns.InitializeOptions()
		end
	elseif event == "PLAYER_LOGIN" then
		invalidateBagScan()
		if C_Timer and C_Timer.NewTicker then
			scanTicker = C_Timer.NewTicker(60, ns.Scan)
		else
			local elapsedSinceScan = 0
			eventFrame:SetScript("OnUpdate", function(_, elapsed)
				elapsedSinceScan = elapsedSinceScan + elapsed
				if elapsedSinceScan >= 60 then
					elapsedSinceScan = elapsedSinceScan % 60
					ns.Scan()
				end
			end)
		end
		ns.Scan()
	elseif event == "BAG_UPDATE_DELAYED" then
		invalidateBagScan()
		ns.Scan()
	elseif event == "PLAYER_ENTERING_WORLD" then
		invalidateBagScan()
		ns.Scan()
	elseif event == "PLAYER_REGEN_DISABLED" then
		if ns.HideScreenAlert then
			ns.HideScreenAlert()
		end
	elseif event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_UPDATE_RESTING" then
		ns.Scan()
	elseif event == "UNIT_AURA" then
		if arg1 == "player" then
			auraTooltipCache = {}
			ns.Scan()
		end
	elseif event == "GET_ITEM_INFO_RECEIVED" then
		invalidateBagScan(arg1)
		ns.Scan()
	end
end)