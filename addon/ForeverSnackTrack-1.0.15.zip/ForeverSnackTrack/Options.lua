local addonName, ns = ...
local L = ForeverSnackTrackL

local function makeCheckbox(parent, name, label, y)
	local checkbox = CreateFrame("CheckButton", name, parent, "InterfaceOptionsCheckButtonTemplate")
	checkbox:SetPoint("TOPLEFT", parent, "TOPLEFT", 24, y)
	_G[name .. "Text"]:SetText(label)
	return checkbox
end

local function makeSectionLabel(parent, label, y)
	local sectionLabel = parent:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	sectionLabel:SetPoint("TOPLEFT", parent, "TOPLEFT", 24, y)
	sectionLabel:SetText(label)
	return sectionLabel
end

local function refreshOptions()
	local panel = ns.optionsPanel
	if not panel or not ns.db then
		return
	end

	panel.chatCheckbox:SetChecked(ns.db.chatAlerts)
	panel.screenCheckbox:SetChecked(ns.db.screenAlerts)
	panel.iconCheckbox:SetChecked(ns.db.screenIconMode)
	panel.noFoodCheckbox:SetChecked(ns.db.remindWhenNoFood)
	panel.sleepingBagCheckbox:SetChecked(ns.db.trackSleepingBagBuff)
	panel.restingCheckbox:SetChecked(ns.db.remindWhileResting)
	panel.repeatCheckbox:SetChecked(ns.db.repeatReminders)
	panel.lowFoodThresholdSlider:SetValue(ns.db.lowFoodThreshold)
	panel.intervalSlider:SetValue(ns.db.reminderMinutes)
	panel.intervalSlider:SetEnabled(ns.db.repeatReminders)
	panel.buffExpirySlider:SetValue(ns.db.buffExpiryWarningMinutes)
	if UIDropDownMenu_SetSelectedValue then
		UIDropDownMenu_SetSelectedValue(panel.snoozeDropdown, ns.db.snoozeMinutes)
	end
	panel.messageBox:SetText(ns.db.screenMessage)
	panel.durationSlider:SetValue(ns.db.screenDuration == 0 and 21 or ns.db.screenDuration)
	panel.scaleSlider:SetValue(ns.db.screenScale * 100)
	panel.colorSwatch:SetColorTexture(ns.db.screenColor.r, ns.db.screenColor.g, ns.db.screenColor.b)
	ns.RefreshFoodSupplyDisplay()
end

function ns.OpenOptions()
	if ns.settingsCategory and Settings and Settings.OpenToCategory then
		Settings.OpenToCategory(ns.settingsCategory:GetID())
	elseif ns.settingsCategoryID and InterfaceOptionsFrame_OpenToCategory then
		InterfaceOptionsFrame_OpenToCategory(ns.settingsCategoryID)
	end
end

function ns.InitializeOptions()
	if ns.optionsPanel then
		return
	end

	local panel = CreateFrame("Frame", "ForeverSnackTrackOptionsPanel", UIParent)
	panel.name = "Forever SnackTrack"
	ns.optionsPanel = panel

	local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", panel, "TOPLEFT", 24, -24)
	title:SetText("Forever SnackTrack")

	local description = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	description:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -12)
	description:SetWidth(560)
	description:SetJustifyH("LEFT")
	description:SetText(L.description)

	panel.remindersSection = makeSectionLabel(panel, L.remindersSection, -82)
	panel.chatCheckbox = makeCheckbox(panel, "ForeverSnackTrackChatCheckbox", L.chatOption, -105)
	panel.screenCheckbox = makeCheckbox(panel, "ForeverSnackTrackScreenCheckbox", L.screenOption, -135)
	panel.repeatCheckbox = makeCheckbox(panel, "ForeverSnackTrackRepeatCheckbox", L.repeatOption, -165)
	panel.noFoodCheckbox = makeCheckbox(panel, "ForeverSnackTrackNoFoodCheckbox", L.noFoodOption, -195)
	panel.restingCheckbox = makeCheckbox(panel, "ForeverSnackTrackRestingCheckbox", L.restingOption, -225)
	panel.iconCheckbox = makeCheckbox(panel, "ForeverSnackTrackIconCheckbox", L.screenIconOption, -135)
	panel.iconCheckbox:ClearAllPoints()
	panel.iconCheckbox:SetPoint("TOPLEFT", panel, "TOPLEFT", 340, -135)
	panel.iconCheckbox:SetScript("OnClick", function(self)
		ns.db.screenIconMode = self:GetChecked()
		ns.RefreshAlertMode()
	end)
	panel.sleepingBagCheckbox = makeCheckbox(panel, "ForeverSnackTrackSleepingBagCheckbox",
		L.sleepingBagOption, -165)
	panel.sleepingBagCheckbox:ClearAllPoints()
	panel.sleepingBagCheckbox:SetPoint("TOPLEFT", panel, "TOPLEFT", 340, -165)
	panel.sleepingBagCheckbox:SetScript("OnClick", function(self)
		ns.db.trackSleepingBagBuff = self:GetChecked()
		if ns.ResetSleepingBagTrackingState then
			ns.ResetSleepingBagTrackingState()
		end
		ns.Scan()
	end)

	panel.chatCheckbox:SetScript("OnClick", function(self)
		ns.db.chatAlerts = self:GetChecked()
		ns.Scan()
	end)
	panel.screenCheckbox:SetScript("OnClick", function(self)
		ns.db.screenAlerts = self:GetChecked()
		if not ns.db.screenAlerts then
			ns.HideScreenAlert()
		end
		ns.Scan()
	end)
	panel.repeatCheckbox:SetScript("OnClick", function(self)
		ns.db.repeatReminders = self:GetChecked()
		panel.intervalSlider:SetEnabled(ns.db.repeatReminders)
		ns.Scan()
	end)
	panel.noFoodCheckbox:SetScript("OnClick", function(self)
		ns.db.remindWhenNoFood = self:GetChecked()
		ns.Scan()
	end)
	panel.restingCheckbox:SetScript("OnClick", function(self)
		ns.db.remindWhileResting = self:GetChecked()
		ns.Scan()
	end)

	panel.timingSection = makeSectionLabel(panel, L.reminderTimingSection, -250)
	local intervalLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	intervalLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 48, -272)
	intervalLabel:SetText(string.format(L.interval, ns.db.reminderMinutes))

	panel.intervalSlider = CreateFrame("Slider", "ForeverSnackTrackIntervalSlider", panel, "OptionsSliderTemplate")
	panel.intervalSlider:SetPoint("TOPLEFT", intervalLabel, "BOTTOMLEFT", 0, -12)
	panel.intervalSlider:SetMinMaxValues(1, 60)
	panel.intervalSlider:SetValueStep(1)
	panel.intervalSlider:SetObeyStepOnDrag(true)
	panel.intervalSlider:SetWidth(260)
	panel.intervalSlider:SetScript("OnValueChanged", function(_, value)
		local minutes = math.floor(value + 0.5)
		ns.db.reminderMinutes = minutes
		intervalLabel:SetText(string.format(L.interval, minutes))
	end)

	local buffExpiryLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	buffExpiryLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 48, -337)
	buffExpiryLabel:SetWidth(270)
	buffExpiryLabel:SetJustifyH("LEFT")
	buffExpiryLabel:SetWordWrap(true)
	buffExpiryLabel:SetText(string.format(L.buffExpiryWarning, ns.db.buffExpiryWarningMinutes))

	panel.buffExpirySlider = CreateFrame("Slider", "ForeverSnackTrackBuffExpirySlider", panel, "OptionsSliderTemplate")
	panel.buffExpirySlider:SetPoint("TOPLEFT", buffExpiryLabel, "BOTTOMLEFT", 0, -12)
	panel.buffExpirySlider:SetMinMaxValues(0, 15)
	panel.buffExpirySlider:SetValueStep(1)
	panel.buffExpirySlider:SetObeyStepOnDrag(true)
	panel.buffExpirySlider:SetWidth(260)
	panel.buffExpirySlider:SetScript("OnValueChanged", function(_, value)
		local minutes = math.floor(value + 0.5)
		ns.db.buffExpiryWarningMinutes = minutes
		buffExpiryLabel:SetText(string.format(L.buffExpiryWarning, minutes))
	end)
	panel.buffExpirySlider:SetScript("OnMouseUp", function()
		ns.Scan()
	end)

	local lowFoodThresholdLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	lowFoodThresholdLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 340, -337)
	lowFoodThresholdLabel:SetWidth(260)
	lowFoodThresholdLabel:SetJustifyH("LEFT")
	lowFoodThresholdLabel:SetWordWrap(true)
	local function updateLowFoodThresholdLabel(threshold)
		local value
		if threshold == 0 then
			value = L.lowFoodThresholdDisabled
		else
			local template = threshold == 1 and L.lowFoodThresholdSingle or L.lowFoodThresholdServings
			value = string.format(template, threshold)
		end
		lowFoodThresholdLabel:SetText(string.format(L.lowFoodThreshold, value))
	end
	panel.lowFoodThresholdSlider = CreateFrame("Slider", "ForeverSnackTrackLowFoodThresholdSlider", panel,
		"OptionsSliderTemplate")
	panel.lowFoodThresholdSlider:SetPoint("TOPLEFT", lowFoodThresholdLabel, "BOTTOMLEFT", 0, -12)
	panel.lowFoodThresholdSlider:SetMinMaxValues(0, 20)
	panel.lowFoodThresholdSlider:SetValueStep(1)
	panel.lowFoodThresholdSlider:SetObeyStepOnDrag(true)
	panel.lowFoodThresholdSlider:SetWidth(260)
	panel.lowFoodThresholdSlider:SetScript("OnValueChanged", function(_, value)
		local threshold = math.floor(value + 0.5)
		if threshold ~= ns.db.lowFoodThreshold and ns.ResetLowStockReminder then
			ns.ResetLowStockReminder()
		end
		ns.db.lowFoodThreshold = threshold
		updateLowFoodThresholdLabel(threshold)
	end)
	panel.lowFoodThresholdSlider:SetScript("OnMouseUp", function()
		ns.Scan()
	end)

	local snoozeLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	snoozeLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 340, -272)
	snoozeLabel:SetText(L.snoozeOption)

	panel.snoozeDropdown = CreateFrame("Frame", "ForeverSnackTrackSnoozeDropdown", panel, "UIDropDownMenuTemplate")
	panel.snoozeDropdown:SetPoint("TOPLEFT", snoozeLabel, "BOTTOMLEFT", -16, -2)
	if UIDropDownMenu_SetWidth then
		UIDropDownMenu_SetWidth(panel.snoozeDropdown, 105)
	end
	updateLowFoodThresholdLabel(ns.db.lowFoodThreshold)
	if UIDropDownMenu_Initialize and UIDropDownMenu_CreateInfo and UIDropDownMenu_AddButton then
		UIDropDownMenu_Initialize(panel.snoozeDropdown, function(_, level)
			for _, minutes in ipairs({ 1, 5, 10, 15, 30, 60 }) do
				local duration = minutes
				local info = UIDropDownMenu_CreateInfo()
				info.text = string.format(L.snoozeDuration, duration)
				info.value = duration
				info.checked = ns.db.snoozeMinutes == duration
				info.func = function()
					ns.db.snoozeMinutes = duration
					if UIDropDownMenu_SetSelectedValue then
						UIDropDownMenu_SetSelectedValue(panel.snoozeDropdown, duration)
					end
					ns.RefreshAlertButtons()
				end
				UIDropDownMenu_AddButton(info, level)
			end
		end)
	end

	local messageLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	messageLabel:SetPoint("TOPLEFT", panel, "TOPLEFT", 48, -402)
	messageLabel:SetText(L.screenMessageLabel)

	local messageHint = panel:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	messageHint:SetPoint("TOPLEFT", messageLabel, "BOTTOMLEFT", 0, -4)
	messageHint:SetText(L.screenMessageHint)

	panel.messageBox = CreateFrame("EditBox", "ForeverSnackTrackMessageEditBox", panel, "InputBoxTemplate")
	panel.messageBox:SetSize(390, 24)
	panel.messageBox:SetPoint("TOPLEFT", messageHint, "BOTTOMLEFT", 0, -8)
	panel.messageBox:SetAutoFocus(false)
	panel.messageBox:SetMaxLetters(200)
	panel.messageBox:SetScript("OnTextChanged", function(self)
		ns.db.screenMessage = self:GetText()
	end)

	panel.previewButton = CreateFrame("Button", "ForeverSnackTrackPreviewButton", panel, "UIPanelButtonTemplate")
	panel.previewButton:SetSize(150, 24)
	panel.previewButton:SetPoint("LEFT", panel.messageBox, "RIGHT", 14, 0)
	panel.previewButton:SetText(L.previewMove)
	panel.previewButton:SetScript("OnClick", function()
		panel.messageBox:ClearFocus()
		local message = ns.db.screenMessage
		ns.ShowScreenAlert(message ~= "" and message or string.format(L.chatMessage, 5), true)
	end)

	local durationLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	durationLabel:SetPoint("TOPLEFT", panel.messageBox, "BOTTOMLEFT", 0, -24)
	durationLabel:SetText(ns.db.screenDuration == 0 and L.screenDurationUnlimited
		or string.format(L.screenDuration, ns.db.screenDuration))

	panel.durationSlider = CreateFrame("Slider", "ForeverSnackTrackDurationSlider", panel, "OptionsSliderTemplate")
	panel.durationSlider:SetPoint("TOPLEFT", durationLabel, "BOTTOMLEFT", 0, -12)
	panel.durationSlider:SetMinMaxValues(1, 21)
	panel.durationSlider:SetValueStep(1)
	panel.durationSlider:SetObeyStepOnDrag(true)
	panel.durationSlider:SetWidth(260)
	panel.durationSlider:SetScript("OnValueChanged", function(_, value)
		local seconds = math.floor(value + 0.5)
		ns.db.screenDuration = seconds == 21 and 0 or seconds
		durationLabel:SetText(ns.db.screenDuration == 0 and L.screenDurationUnlimited
			or string.format(L.screenDuration, ns.db.screenDuration))
		ns.RefreshScreenAlert()
	end)

	local scaleLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	scaleLabel:SetPoint("TOPLEFT", panel.durationSlider, "BOTTOMLEFT", 0, -24)
	scaleLabel:SetText(string.format(L.screenScale, math.floor(ns.db.screenScale * 100 + 0.5)))

	panel.scaleSlider = CreateFrame("Slider", "ForeverSnackTrackScaleSlider", panel, "OptionsSliderTemplate")
	panel.scaleSlider:SetPoint("TOPLEFT", scaleLabel, "BOTTOMLEFT", 0, -12)
	panel.scaleSlider:SetMinMaxValues(25, 150)
	panel.scaleSlider:SetValueStep(5)
	panel.scaleSlider:SetObeyStepOnDrag(true)
	panel.scaleSlider:SetWidth(260)
	panel.scaleSlider:SetScript("OnValueChanged", function(_, value)
		local percent = math.floor(value / 5 + 0.5) * 5
		ns.db.screenScale = percent / 100
		scaleLabel:SetText(string.format(L.screenScale, percent))
		ns.RefreshAlertMode()
	end)

	local colorLabel = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	colorLabel:SetPoint("TOPLEFT", panel.scaleSlider, "BOTTOMLEFT", 0, -24)
	colorLabel:SetText(L.screenColor)

	panel.colorButton = CreateFrame("Button", "ForeverSnackTrackColorButton", panel, "UIPanelButtonTemplate")
	panel.colorButton:SetSize(110, 24)
	panel.colorButton:SetPoint("LEFT", colorLabel, "RIGHT", 12, 0)
	panel.colorButton:SetText(L.screenColor)
	panel.colorSwatch = panel.colorButton:CreateTexture(nil, "OVERLAY")
	panel.colorSwatch:SetSize(16, 16)
	panel.colorSwatch:SetPoint("RIGHT", panel.colorButton, "RIGHT", -6, 0)
	panel.colorButton:SetScript("OnClick", function()
		if not ColorPickerFrame or not ColorPickerFrame.SetupColorPickerAndShow then
			return
		end

		local color = ns.db.screenColor
		ColorPickerFrame:SetupColorPickerAndShow({
			r = color.r,
			g = color.g,
			b = color.b,
			hasOpacity = false,
			swatchFunc = function()
				local r, g, b = ColorPickerFrame:GetColorRGB()
				ns.db.screenColor = { r = r, g = g, b = b }
				panel.colorSwatch:SetColorTexture(r, g, b)
				ns.RefreshScreenAlert()
			end,
			cancelFunc = function(previous)
				ns.db.screenColor = { r = previous.r, g = previous.g, b = previous.b }
				panel.colorSwatch:SetColorTexture(previous.r, previous.g, previous.b)
				ns.RefreshScreenAlert()
			end,
		})
	end)

	panel.resetPositionButton = CreateFrame("Button", "ForeverSnackTrackResetPositionButton", panel, "UIPanelButtonTemplate")
	panel.resetPositionButton:SetSize(145, 24)
	panel.resetPositionButton:SetPoint("LEFT", panel.colorButton, "RIGHT", 12, 0)
	panel.resetPositionButton:SetText(L.resetPosition)
	panel.resetPositionButton:SetScript("OnClick", function()
		ns.ResetScreenAlertPosition()
	end)
	panel.supplyText = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	panel.supplyText:SetPoint("TOPLEFT", panel, "TOPLEFT", 340, -200)
	panel.supplyText:SetWidth(300)
	panel.supplyText:SetJustifyH("LEFT")
	panel.supplyText:SetWordWrap(true)

	panel:SetScript("OnShow", refreshOptions)
	panel:SetScript("OnHide", function()
		if ns.alertFrame and ns.alertFrame.isPreview then
			ns.HideScreenAlert()
		end
		ns.Scan()
	end)
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		ns.settingsCategory = Settings.RegisterCanvasLayoutCategory(panel, "Forever SnackTrack")
		Settings.RegisterAddOnCategory(ns.settingsCategory)
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(panel)
		ns.settingsCategoryID = panel.name
	end

	SLASH_FOREVERSNACKTRACK1 = "/snacktrack"
	SLASH_FOREVERSNACKTRACK2 = "/fst"
	SlashCmdList.FOREVERSNACKTRACK = function(message)
		local command = (message or ""):lower():match("^%s*(.-)%s*$")
		if command == "debug" then
			ns.DebugStatus()
		elseif command == "debug sleepingbag" then
			ns.DebugSleepingBagStatus()
		elseif command == "bag" then
			ns.ToggleSleepingBagTimeline()
		else
			ns.OpenOptions()
		end
	end
	refreshOptions()
end